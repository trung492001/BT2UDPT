<table class="table" id="tasksTable" style="table-layout: auto">
    <thead>
        <tr>
            <th> <input type="checkbox" value="All" id="allTask"></th>
            <th scope="col">Tên công việc</th>
            <th scope="col">Mô tả</th>
            <th scope="col">Ngày bắt đầu</th>
            <th scope="col">Ngày kết thúc</th>
            <th scope="col">Loại</th>
            <th scope="col">Ngày hoàn thành</th>
            <th scope="col">Trạng thái</th>
            <th scope="col">Chức năng</th>
        </tr>
    </thead>
    <tbody>

    </tbody>
</table>