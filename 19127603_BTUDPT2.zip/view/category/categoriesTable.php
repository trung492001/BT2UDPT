<table class="table" id="categoriesTable">
    <thead>
        <tr>
            <th class="align-middle">
                <input type="checkbox" value="All" id="allCategory">
            </th>
            <th scope="col" style="width: 250px">Tên loại công việc</th>
            <th scope="col" style="width: 200px">Ngày tạo</th>
            <th scope="col" style="width: 200px">Chức năng</th>
        </tr>
    </thead>
    <tbody>

    </tbody>
</table>