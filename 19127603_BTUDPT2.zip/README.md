# BT2UDPT

## Các chức năng hoàn thành

- Thêm công việc
- Tìm kiếm công việc (theo tên + mô tả)
- Lọc công việc (sắp hết hạn, đang thực hiện, hoàn thành)
- Xem chi tiết công việc
- Xoá 1 công việc/lần
- Xoá nhiều công việc/ lần: chọn công việc trên các trang khác nhau
- Xoá tất cả trên cùng 1 trang: chọn checkbox trên đầu cột nếu di chuyển sang trang khác thì mới được tính là sẽ xóa luôn cả trang đó còn ko chỉ xóa tất cả trên trang hiện tại
- Cập nhật công việc (thông tin + trạng thái)
- Có phân trang trong khi xem danh sách công việc

## Các chức năng chưa hoàn thành

- Chưa hiển thị báo lỗi nếu loại công việc bị tham chiếu bởi công việc
- Chỉ sử dụng required bình thường của tag input chứ không xài javascript để hiển thị nội dung required
