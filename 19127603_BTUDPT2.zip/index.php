<?php

header('Location: view/task/index.php');
